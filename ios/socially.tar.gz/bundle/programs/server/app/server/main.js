(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/main.js                                                      //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
System.register("server/main", ['./load-parties'], function(exports_1) {
    var load_parties_1;                                                //
    return {                                                           //
        setters:[                                                      //
            function (load_parties_1_1) {                              //
                load_parties_1 = load_parties_1_1;                     //
            }],                                                        //
        execute: function() {                                          //
            Meteor.startup(load_parties_1.loadParties);                //
        }                                                              //
    }                                                                  //
});                                                                    //
//# sourceMappingURL=main.js.map                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=main.js.map
