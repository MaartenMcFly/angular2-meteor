(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collections/parties.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
System.register("collections/parties", [], function(exports_1) {       //
    var Parties;                                                       //
    return {                                                           //
        setters:[],                                                    //
        execute: function() {                                          //
            exports_1("Parties", Parties = new Mongo.Collection('parties'));
        }                                                              //
    }                                                                  //
});                                                                    //
//# sourceMappingURL=parties.js.map                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=parties.js.map
