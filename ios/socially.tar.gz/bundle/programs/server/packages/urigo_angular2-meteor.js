(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var EJSON = Package.ejson.EJSON;
var check = Package.check.check;
var Match = Package.check.Match;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var babelHelpers = Package['babel-runtime'].babelHelpers;
var System = Package['systemjs:systemjs'].System;
var Promise = Package.promise.Promise;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/urigo_angular2-meteor/system_config.js                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
System.config({                                                      // 1
  packages: {                                                        // 2
    'angular2-meteor': {                                             // 3
      main: 'main',                                                  // 4
      format: 'register',                                            // 5
      map: {                                                         // 6
        '.': System.normalizeSync('{urigo:angular2-meteor}')         // 7
      }                                                              // 8
    }                                                                // 9
  }                                                                  // 10
});                                                                  // 11
                                                                     // 12
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['urigo:angular2-meteor'] = {};

})();

//# sourceMappingURL=urigo_angular2-meteor.js.map
