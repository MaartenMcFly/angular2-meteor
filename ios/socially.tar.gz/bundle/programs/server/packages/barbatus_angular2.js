(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var Promise = Package.promise.Promise;
var System = Package['systemjs:systemjs'].System;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/barbatus_angular2/system_config.js                       //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
'user strict';                                                       // 1
                                                                     // 2
var oldRegister = System.register;                                   // 3
var mainRegex = /^server\/main$/;                                    // 4
var appRegex = /(^client\/app$)|(^app$)/g;                           // 5
System.register = function(name, deps, declare) {                    // 6
  oldRegister.call(this, name, deps, declare);                       // 7
                                                                     // 8
  // Imports server main module (server/main.ts).                    // 9
  if (Meteor.isServer && mainRegex.test(name)) {                     // 10
    Meteor.startup(function() {                                      // 11
      // Does import synchronously in the main app fiber.            // 12
      System.import(name).await();                                   // 13
    });                                                              // 14
  }                                                                  // 15
                                                                     // 16
  // Imports client main module (client/app.ts).                     // 17
  if (Meteor.isClient && appRegex.test(name)) {                      // 18
    Meteor.startup(function() {                                      // 19
      System.import(name);                                           // 20
    });                                                              // 21
  }                                                                  // 22
};                                                                   // 23
                                                                     // 24
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['barbatus:angular2'] = {};

})();

//# sourceMappingURL=barbatus_angular2.js.map
